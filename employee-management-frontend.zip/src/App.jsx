import { useEffect, useState } from "react";

const API_URL = "http://localhost:8080/api/employees";

const emptyEmployee = {
  name: "",
  email: "",
  department: "",
  position: "",
  salary: ""
};

function App() {
  const [employees, setEmployees] = useState([]);
  const [form, setForm] = useState(emptyEmployee);
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  const loadEmployees = async () => {
    try {
      const response = await fetch(API_URL);
      if (!response.ok) throw new Error();
      const data = await response.json();
      setEmployees(data);
    } catch {
      setMessage("Unable to connect to the backend.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEmployees();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.department || !form.position || !form.salary) {
      setMessage("Please fill all fields.");
      return;
    }

    const method = editingId ? "PUT" : "POST";
    const url = editingId ? `${API_URL}/${editingId}` : API_URL;

    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, salary: Number(form.salary) })
      });

      if (!response.ok) throw new Error();

      setForm(emptyEmployee);
      setEditingId(null);
      setMessage(editingId ? "Employee updated." : "Employee added.");
      loadEmployees();
    } catch {
      setMessage("Operation failed.");
    }
  };

  const handleEdit = (employee) => {
    setEditingId(employee.id);
    setForm({
      name: employee.name,
      email: employee.email,
      department: employee.department,
      position: employee.position,
      salary: employee.salary
    });
    setMessage("");
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this employee?")) return;

    try {
      const response = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
      if (!response.ok) throw new Error();
      setMessage("Employee deleted.");
      loadEmployees();
    } catch {
      setMessage("Delete failed.");
    }
  };

  const filteredEmployees = employees.filter((employee) =>
    `${employee.name} ${employee.email} ${employee.department} ${employee.position}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <div className="app">
      <header className="header">
        <div>
          <h1>Employee Management System</h1>
          <p>Manage employees with a simple React and Spring Boot application.</p>
        </div>
        <div className="employee-count">{employees.length} Employees</div>
      </header>

      <main className="container">
        <section className="card form-card">
          <h2>{editingId ? "Edit Employee" : "Add Employee"}</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-grid">
              <input name="name" value={form.name} onChange={handleChange} placeholder="Full Name" />
              <input name="email" type="email" value={form.email} onChange={handleChange} placeholder="Email" />
              <input name="department" value={form.department} onChange={handleChange} placeholder="Department" />
              <input name="position" value={form.position} onChange={handleChange} placeholder="Position" />
              <input name="salary" type="number" min="0" value={form.salary} onChange={handleChange} placeholder="Salary" />
            </div>
            <div className="actions">
              <button type="submit">{editingId ? "Update Employee" : "Add Employee"}</button>
              {editingId && (
                <button type="button" className="secondary" onClick={() => {
                  setEditingId(null);
                  setForm(emptyEmployee);
                  setMessage("");
                }}>
                  Cancel
                </button>
              )}
            </div>
          </form>
          {message && <p className="message">{message}</p>}
        </section>

        <section className="card">
          <div className="table-header">
            <h2>Employees</h2>
            <input
              className="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search employees..."
            />
          </div>

          {loading ? (
            <p className="empty">Loading...</p>
          ) : filteredEmployees.length === 0 ? (
            <p className="empty">No employees found.</p>
          ) : (
            <div className="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Department</th>
                    <th>Position</th>
                    <th>Salary</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEmployees.map((employee) => (
                    <tr key={employee.id}>
                      <td>{employee.name}</td>
                      <td>{employee.email}</td>
                      <td>{employee.department}</td>
                      <td>{employee.position}</td>
                      <td>₹{Number(employee.salary).toLocaleString("en-IN")}</td>
                      <td>
                        <div className="row-actions">
                          <button className="edit" onClick={() => handleEdit(employee)}>Edit</button>
                          <button className="delete" onClick={() => handleDelete(employee.id)}>Delete</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

export default App;
