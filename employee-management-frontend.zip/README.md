# Employee Management Frontend

## Requirements

- Node.js 18+

## Run

```bash
npm install
npm run dev
```

The frontend expects the Spring Boot backend at `http://localhost:8080`.
